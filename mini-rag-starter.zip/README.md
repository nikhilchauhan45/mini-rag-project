
# Mini RAG (Track B)

A tiny Retrieval-Augmented Generation app. Paste/upload text, we chunk+embed it, store in Qdrant, retrieve + Jina rerank, and answer via OpenAI with inline citations.

## Live stack
- Next.js 14 (Pages Router) on Vercel
- Embeddings: OpenAI `text-embedding-3-small` (1536 dims)
- Vector DB: Qdrant Cloud (collection: `mini_rag_docs`, cosine)
- Retriever: Top-k = 8 from Qdrant
- Reranker: Jina Reranker v2 (multilingual), fallback to vector order
- LLM: OpenAI `gpt-4o-mini`
- Chunking: ~1000 words, 120 overlap
- Metadata: `source`, `title`, `section`, `position`, `text`

## Quick start
1. Create a Qdrant cluster and note **QDRANT_URL** and **QDRANT_API_KEY**.
2. Create **OPENAI_API_KEY**.
3. Create **JINA_API_KEY** (optional but recommended).
4. On Vercel, add the env vars:

```
OPENAI_API_KEY=...
QDRANT_URL=...
QDRANT_API_KEY=...
JINA_API_KEY=...
# optional: customize
QDRANT_COLLECTION=mini_rag_docs
```

5. Deploy on Vercel. First screen should load. Ingest some text, then ask a question.

## Local dev
```bash
npm install
npm run dev
```

## Minimal eval
Add at least 5 Q/A pairs you expect to work (put them here). Measure success rate by manual check.

## Remarks
- If provider limits hit, downgrade usage or try fewer top-k chunks.
- If Jina API is missing/limited, rerank step is skipped (vector order used).
- Security: API keys must stay server-side. Do NOT put keys in client.
