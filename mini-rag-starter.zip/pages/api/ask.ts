import type { NextApiRequest, NextApiResponse } from 'next';
import { search } from '@/lib/qdrant';
import { embed, answer } from '@/lib/openai';
import { rerankWithJina } from '@/lib/rerank';

const COLLECTION = process.env.QDRANT_COLLECTION || "mini_rag_docs";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const t0 = Date.now();
  try {
    const { query, topK = 8 } = req.body as { query: string, topK?: number };
    if (!query || query.trim().length < 2) return res.status(400).json({ error: "Empty query" });

    const [qvec] = await embed([query]);
    const url = process.env.QDRANT_URL!;
    const apiKey = process.env.QDRANT_API_KEY!;
    const raw = await search(url, apiKey, COLLECTION, qvec, topK);

    const docs = raw.map((r:any)=>({ 
      text: r.payload?.text as string, 
      meta: { source: r.payload?.source, title: r.payload?.title, position: r.payload?.position, score: r.score } 
    }));

    const jinaKey = process.env.JINA_API_KEY || "";
    const reranked = jinaKey ? await rerankWithJina(jinaKey, query, docs) : docs;

    const picked = reranked.slice(0, 5);
    const ans = await answer(query, picked);
    const t1 = Date.now();
    const timing = { total_ms: t1 - t0 };

    return res.status(200).json({ 
      ok: true, 
      answer: ans.content, 
      citations: ans.citations, 
      sources: picked, 
      timing 
    });
  } catch (e:any) {
    return res.status(500).json({ error: e.message || "Ask failed" });
  }
}
