import type { NextApiRequest, NextApiResponse } from 'next';
import { chunkText } from '@/lib/chunk';
import { ensureCollection, upsertPoints } from '@/lib/qdrant';
import { embed } from '@/lib/openai';

const COLLECTION = process.env.QDRANT_COLLECTION || "mini_rag_docs";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  try {
    const { text, meta } = req.body as { text: string, meta?: any };
    if (!text || text.trim().length < 5) return res.status(400).json({ error: "No text to ingest" });

    const url = process.env.QDRANT_URL!;
    const apiKey = process.env.QDRANT_API_KEY!;
    await ensureCollection(url, apiKey, COLLECTION, 1536);

    const chunks = chunkText(text, 1000, 120);
    const embeddings = await embed(chunks.map(c => c.content));
    const points = embeddings.map((vec, i) => ({
      id: `${Date.now()}-${i}`,
      vector: vec,
      payload: {
        source: meta?.source || "upload",
        title: meta?.title || "Untitled",
        section: meta?.section || null,
        position: i,
        text: chunks[i].content
      }
    }));

    await upsertPoints(url, apiKey, COLLECTION, points);
    return res.status(200).json({ ok: true, chunks: points.length });
  } catch (e:any) {
    return res.status(500).json({ error: e.message || "Ingest failed" });
  }
}
