import { useState } from 'react';
import Head from 'next/head';
import '../styles.css';

export default function Home() {
  const [paste, setPaste] = useState('');
  const [fileText, setFileText] = useState('');
  const [query, setQuery] = useState('');
  const [answer, setAnswer] = useState<string|null>(null);
  const [sources, setSources] = useState<any[]>([]);
  const [citations, setCitations] = useState<string[]>([]);
  const [status, setStatus] = useState<string>('Ready');
  const [timing, setTiming] = useState<any>(null);

  async function handleFile(e: any) {
    const f = e.target.files?.[0];
    if (!f) return;
    const text = await f.text();
    setFileText(text);
  }

  async function ingest() {
    const text = [paste, fileText].filter(Boolean).join('\n\n');
    if (!text || text.length < 5) { alert('Kuch text to do yaar 🙂'); return; }
    setStatus('Ingesting...');
    const t0 = performance.now();
    const resp = await fetch('/api/ingest', { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify({ text, meta: { source: 'upload', title: 'User Upload' }})});
    const data = await resp.json();
    const t1 = performance.now();
    if (!resp.ok) { setStatus('Ingest failed: ' + data.error); return; }
    setStatus(`Ingested ${data.chunks} chunks in ${(t1-t0).toFixed(0)}ms`);
  }

  async function ask() {
    if (!query) { alert('Question likh!'); return; }
    setStatus('Thinking...');
    setAnswer(null); setSources([]); setCitations([]);
    const t0 = performance.now();
    const resp = await fetch('/api/ask', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ query })});
    const data = await resp.json();
    const t1 = performance.now();
    if (!resp.ok) { setStatus('Ask failed: ' + data.error); return; }
    setAnswer(data.answer); setSources(data.sources || []); setCitations(data.citations || []);
    setTiming({ total_ms: (t1-t0).toFixed(0), api: data.timing?.total_ms });
    setStatus('Done');
  }

  return (
    <div className="container">
      <Head><title>Mini RAG</title></Head>
      <div className="row" style={{alignItems:'center', justifyContent:'space-between'}}>
        <h1>Mini RAG 🔎</h1>
        <span className="badge">{status}</span>
      </div>

      <div className="grid" style={{marginTop:16}}>
        <div className="card">
          <h3>Paste ya Upload</h3>
          <textarea className="input" rows={8} placeholder="Yaha text paste karo..." value={paste} onChange={e=>setPaste(e.target.value)} />
          <div style={{display:'flex', gap:12, alignItems:'center', marginTop:8}}>
            <input type="file" accept=".txt,.md,.pdf,.json" onChange={handleFile} />
            <button className="btn" onClick={ingest}>Ingest to Vector DB</button>
          </div>
          <div className="small" style={{marginTop:8}}>Chunking: ~1000 words, 120 overlap. Embeddings: text-embedding-3-small (1536 dims). DB: Qdrant.</div>
        </div>

        <div className="card">
          <h3>Ask</h3>
          <input className="input" placeholder="Apna sawaal likho..." value={query} onChange={e=>setQuery(e.target.value)} />
          <div style={{display:'flex', gap:12, marginTop:8}}>
            <button className="btn" onClick={ask}>Ask</button>
            {timing && <span className="small">~{timing.total_ms} ms</span>}
          </div>
          {answer && (
            <div style={{marginTop:16}}>
              <div className="card">
                <h4>Answer</h4>
                <div className="code">{answer}</div>
                {citations?.length > 0 && (
                  <div style={{marginTop:8}}>
                    <strong>Citations:</strong>
                    <ul>
                      {citations.map((c,i)=>(<li key={i}>{c}</li>))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {sources?.length > 0 && (
        <div className="card" style={{marginTop:16}}>
          <h3>Sources</h3>
          <div className="grid">
            {sources.map((s:any, i:number)=>(
              <div className="source" key={i}>
                <div className="small">Score: {s.meta?.score?.toFixed?.(3)}</div>
                <div style={{fontWeight:600, marginBottom:6}}>{s.meta?.title || 'Untitled'} <span className="small">[{i+1}]</span></div>
                <div className="small">{s.text}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="small" style={{marginTop:16}}>
        Tips: pehle kuch content ingest karo, fir question pucho. <kbd>Ctrl</kbd>+<kbd>F</kbd> se browser me search bhi kar sakte ho 😄
      </div>
    </div>
  );
}
