export function chunkText(text: string, chunkSize = 1200, overlap = 120) {
  const words = text.split(/\s+/);
  const chunks: { id: string; content: string; start: number; end: number }[] = [];
  let start = 0;
  while (start < words.length) {
    const end = Math.min(start + chunkSize, words.length);
    const content = words.slice(start, end).join(' ').trim();
    if (content.length > 0) {
      chunks.push({ id: `${start}-${end}`, content, start, end });
    }
    if (end === words.length) break;
    start = Math.max(0, end - overlap);
  }
  return chunks;
}
