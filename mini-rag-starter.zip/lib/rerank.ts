export async function rerankWithJina(apiKey: string, query: string, docs: {text: string, meta: any}[]) {
  try {
    const body = {
      model: "jina-reranker-v2-base-multilingual",
      query,
      documents: docs.map(d => d.text)
    };
    const res = await fetch("https://api.jina.ai/v1/rerank", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify(body)
    });
    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    // expect data.results as list with index & relevance_score
    const results = (data.results || []).map((r: any, i: number) => ({ idx: r.index ?? i, score: r.relevance_score ?? 0 }));
    // sort by score desc and map back
    return results
      .sort((a:any,b:any)=>b.score-a.score)
      .map((r:any)=>docs[r.idx]);
  } catch (e) {
    // fallback: return original order
    return docs;
  }
}
