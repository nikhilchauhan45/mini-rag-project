export type QPoint = {
  id: string | number;
  vector: number[];
  payload?: Record<string, any>;
};

export async function ensureCollection(url: string, apiKey: string, name: string, size = 1536) {
  const headers: any = { "Content-Type": "application/json", "api-key": apiKey };
  // check
  const res = await fetch(`${url}/collections/${name}`, { headers });
  if (res.ok) return true;
  // create
  const body = {
    vectors: { size, distance: "Cosine" },
    optimizers_config: { default_segment_number: 2 }
  };
  const create = await fetch(`${url}/collections/${name}`, { method: "PUT", headers, body: JSON.stringify(body) });
  if (!create.ok) {
    const t = await create.text();
    throw new Error("Failed to create collection: " + t);
  }
  return true;
}

export async function upsertPoints(url: string, apiKey: string, name: string, points: QPoint[]) {
  const headers: any = { "Content-Type": "application/json", "api-key": apiKey };
  const body = { points };
  const resp = await fetch(`${url}/collections/${name}/points?wait=true`, { method: "PUT", headers, body: JSON.stringify(body) });
  if (!resp.ok) {
    const t = await resp.text();
    throw new Error("Upsert error: " + t);
  }
  return resp.json();
}

export async function search(url: string, apiKey: string, name: string, vector: number[], limit = 8) {
  const headers: any = { "Content-Type": "application/json", "api-key": apiKey };
  const body = { vector, limit, with_payload: true, score_threshold: 0.0 };
  const resp = await fetch(`${url}/collections/${name}/points/search`, { method: "POST", headers, body: JSON.stringify(body) });
  if (!resp.ok) {
    const t = await resp.text();
    throw new Error("Search error: " + t);
  }
  const data = await resp.json();
  return data.result || [];
}
