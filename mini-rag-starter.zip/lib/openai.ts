import OpenAI from 'openai';
export const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

export async function embed(texts: string[]) {
  const resp = await openai.embeddings.create({
    model: "text-embedding-3-small",
    input: texts
  });
  return resp.data.map(d => d.embedding as number[]);
}

export async function answer(query: string, contexts: {text: string, meta: any}[]) {
  const citations = contexts.map((c, i)=>`[${i+1}] ${c.meta?.source ?? 'uploaded'} — ${c.meta?.title ?? ''}`.trim());
  const sys = "You are a helpful RAG assistant. Use only the provided context to answer. Add inline citations like [1], [2] where relevant. If the answer is not in context, say you don't know.";
  const ctxText = contexts.map((c,i)=>`[${i+1}] ${c.text}`).join("\n\n");
  const user = `Question: ${query}\n\nContext:\n${ctxText}`;
  const chat = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: sys },
      { role: "user", content: user }
    ],
    temperature: 0.2
  });
  const content = chat.choices[0]?.message?.content ?? "";
  return { content, citations };
}
